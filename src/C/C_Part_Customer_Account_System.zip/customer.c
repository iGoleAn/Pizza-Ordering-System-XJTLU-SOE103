/*
 * ============================================================================
 * File        : customer.c
 * Module      : C - Customer Account System
 * Course      : SOE103 C Programming and Software Engineering
 * Project     : Pizza Ordering System (Group Project)
 * Description : Implementation of the customer account module.
 *
 * Functions provided:
 *   - register a customer with a unique account number
 *   - edit and delete accounts
 *   - enquire the current balance
 *   - top up (deposit) money
 *   - charge an account when an order is placed (used by order.c)
 *   - load / save the account database to a text file
 *   - a menu-driven interface for both manager and customer
 *
 * All public functions validate their arguments and return a status code.
 * The file is written in C89-compatible style so it can be compiled by any
 * standard C compiler used in the laboratory.
 * ============================================================================
 */

#include "customer.h"

#include <stdio.h>      /* printf, scanf, fgets, FILE, fopen, fprintf, fscanf */
#include <stdlib.h>     /* malloc, realloc, free                              */
#include <string.h>     /* strlen, strcpy, strchr, strtol, strtod             */
#include <ctype.h>      /* isdigit                                            */
#include <limits.h>     /* INT_MAX                                            */

/* ---------------------------------------------------------------------------
 * Internal helper: copy a string safely into a fixed-size field.
 * Guarantees NUL-termination even when the source is longer than the field.
 * ------------------------------------------------------------------------ */
static void copyField(char *dest, int destSize, const char *src)
{
    int i;

    if (destSize <= 0) {
        return;
    }
    if (src == NULL) {
        dest[0] = '\0';
        return;
    }
    for (i = 0; i < destSize - 1 && src[i] != '\0'; i++) {
        dest[i] = src[i];
    }
    dest[i] = '\0';
}

/* ---------------------------------------------------------------------------
 * Internal helper: validate a name.
 * A valid name contains at least one character and no '|' (the field
 * separator used by the data file) and no newline.
 * ------------------------------------------------------------------------ */
static int isValidName(const char *name)
{
    const char *p;

    if (name == NULL) {
        return 0;
    }
    for (p = name; *p != '\0'; p++) {
        if (*p == '|' || *p == '\n' || *p == '\r') {
            return 0;
        }
    }
    /* reject an all-blank name */
    for (p = name; *p != '\0'; p++) {
        if (!isspace((unsigned char)*p)) {
            return 1;
        }
    }
    return 0;
}

/* ---------------------------------------------------------------------------
 * Internal helper: validate a telephone number.
 * Accepts digits, spaces, '+' and '-', but requires at least 6 digits so a
 * single keystroke cannot be registered as a phone number.
 * ------------------------------------------------------------------------ */
static int isValidPhone(const char *phone)
{
    const char *p;
    int digits = 0;

    if (phone == NULL || phone[0] == '\0') {
        return 0;
    }
    for (p = phone; *p != '\0'; p++) {
        if (isdigit((unsigned char)*p)) {
            digits++;
        } else if (*p == ' ' || *p == '-' || *p == '+') {
            /* allowed formatting characters */
        } else {
            return 0;   /* reject '|', letters, control characters, ... */
        }
    }
    return (digits >= 6);
}

/* ---------------------------------------------------------------------------
 * Internal helper: make sure there is room for one more record.
 * The array grows geometrically to keep insertion cheap.
 * Returns CUST_OK or CUST_ERR_NOMEM / CUST_ERR_INVALID.
 * ------------------------------------------------------------------------ */
static int ensureCapacity(CustomerList *list)
{
    Customer *tmp;
    int newCapacity;
    int i;

    if (list == NULL) {
        return CUST_ERR_INVALID;
    }
    if (list->count < list->capacity) {
        return CUST_OK;
    }
    if (list->capacity >= CUST_MAX_RECORDS) {
        return CUST_ERR_NOMEM;      /* configured safety limit reached */
    }

    newCapacity = (list->capacity == 0) ? 4 : list->capacity * 2;
    if (newCapacity > CUST_MAX_RECORDS) {
        newCapacity = CUST_MAX_RECORDS;
    }

    tmp = (Customer *)realloc(list->items, (size_t)newCapacity * sizeof(Customer));
    if (tmp == NULL) {
        return CUST_ERR_NOMEM;      /* original block is left untouched */
    }
    list->items = tmp;

    /* initialise the newly allocated slots */
    for (i = list->capacity; i < newCapacity; i++) {
        list->items[i].accountId = 0;
        list->items[i].name[0] = '\0';
        list->items[i].telephone[0] = '\0';
        list->items[i].balance = 0.0;
        list->items[i].orderCount = 0;
    }
    list->capacity = newCapacity;
    return CUST_OK;
}

/* ---------------------------------------------------------------------------
 * Life-cycle management
 * ------------------------------------------------------------------------ */

void customerListInit(CustomerList *list)
{
    if (list == NULL) {
        return;
    }
    list->items = NULL;
    list->count = 0;
    list->capacity = 0;
    list->nextId = CUST_START_ID;
}

void customerListFree(CustomerList *list)
{
    if (list == NULL) {
        return;
    }
    free(list->items);              /* free(NULL) is harmless */
    list->items = NULL;
    list->count = 0;
    list->capacity = 0;
}

/* ---------------------------------------------------------------------------
 * Core operations
 * ------------------------------------------------------------------------ */

int customerRegister(CustomerList *list, const char *name,
                     const char *telephone, double initialDeposit)
{
    int status;
    int id;

    if (list == NULL || !isValidName(name) || !isValidPhone(telephone)) {
        return CUST_ERR_INVALID;
    }
    if (initialDeposit < 0.0 || initialDeposit > CUST_MAX_BALANCE) {
        return CUST_ERR_INVALID;
    }

    status = ensureCapacity(list);
    if (status != CUST_OK) {
        return status;
    }

    /* The account number is issued from a monotonic counter, therefore it is
     * unique for the lifetime of the program and is never recycled after a
     * deletion.  customerLoad() restores the counter to max(id)+1.        */
    id = list->nextId++;

    list->items[list->count].accountId = id;
    copyField(list->items[list->count].name, CUST_NAME_LEN, name);
    copyField(list->items[list->count].telephone, CUST_PHONE_LEN, telephone);
    list->items[list->count].balance = initialDeposit;
    list->items[list->count].orderCount = 0;
    list->count++;

    return id;                      /* positive value = success */
}

int customerEdit(CustomerList *list, int accountId,
                 const char *newName, const char *newTelephone)
{
    Customer *c;

    if (list == NULL) {
        return CUST_ERR_INVALID;
    }
    if (newName != NULL && !isValidName(newName)) {
        return CUST_ERR_INVALID;
    }
    if (newTelephone != NULL && !isValidPhone(newTelephone)) {
        return CUST_ERR_INVALID;
    }
    if (newName == NULL && newTelephone == NULL) {
        return CUST_ERR_INVALID;    /* nothing to change */
    }

    c = customerFindById(list, accountId);
    if (c == NULL) {
        return CUST_ERR_NOTFOUND;
    }
    if (newName != NULL) {
        copyField(c->name, CUST_NAME_LEN, newName);
    }
    if (newTelephone != NULL) {
        copyField(c->telephone, CUST_PHONE_LEN, newTelephone);
    }
    return CUST_OK;
}

int customerDelete(CustomerList *list, int accountId)
{
    int i;

    if (list == NULL) {
        return CUST_ERR_INVALID;
    }
    for (i = 0; i < list->count; i++) {
        if (list->items[i].accountId == accountId) {
            /* Replace the removed slot with the last record.  Ordering of
             * the array is not significant because lookups use accountId. */
            list->items[i] = list->items[list->count - 1];
            list->count--;
            return CUST_OK;
        }
    }
    return CUST_ERR_NOTFOUND;
}

Customer *customerFindById(CustomerList *list, int accountId)
{
    int i;

    if (list == NULL) {
        return NULL;
    }
    for (i = 0; i < list->count; i++) {
        if (list->items[i].accountId == accountId) {
            return &list->items[i];
        }
    }
    return NULL;
}

const Customer *customerFindByIdConst(const CustomerList *list, int accountId)
{
    int i;

    if (list == NULL) {
        return NULL;
    }
    for (i = 0; i < list->count; i++) {
        if (list->items[i].accountId == accountId) {
            return &list->items[i];
        }
    }
    return NULL;
}

double customerGetBalance(const CustomerList *list, int accountId)
{
    const Customer *c = customerFindByIdConst(list, accountId);

    if (c == NULL) {
        return -1.0;                /* impossible as a real balance */
    }
    return c->balance;
}

int customerDeposit(CustomerList *list, int accountId, double amount)
{
    Customer *c;

    if (list == NULL || amount <= 0.0) {
        return CUST_ERR_INVALID;    /* zero / negative top-up is meaningless */
    }
    c = customerFindById(list, accountId);
    if (c == NULL) {
        return CUST_ERR_NOTFOUND;
    }
    if (c->balance + amount > CUST_MAX_BALANCE) {
        return CUST_ERR_INVALID;    /* would overflow the configured limit */
    }
    c->balance += amount;
    return CUST_OK;
}

int customerCharge(CustomerList *list, int accountId, double amount)
{
    Customer *c;

    if (list == NULL || amount <= 0.0) {
        return CUST_ERR_INVALID;
    }
    c = customerFindById(list, accountId);
    if (c == NULL) {
        return CUST_ERR_NOTFOUND;
    }
    if (c->balance < amount) {
        return CUST_ERR_INSUFFICIENT;
    }
    c->balance -= amount;
    return CUST_OK;
}

int customerAddOrder(CustomerList *list, int accountId)
{
    Customer *c;

    if (list == NULL) {
        return CUST_ERR_INVALID;
    }
    c = customerFindById(list, accountId);
    if (c == NULL) {
        return CUST_ERR_NOTFOUND;
    }
    c->orderCount++;
    return CUST_OK;
}

/* ---------------------------------------------------------------------------
 * Display helpers
 * ------------------------------------------------------------------------ */

void customerPrint(const Customer *c)
{
    if (c == NULL) {
        printf("  (no such account)\n");
        return;
    }
    printf("  %-8d %-20s %-16s %10.2f %8d\n",
           c->accountId, c->name, c->telephone, c->balance, c->orderCount);
}

void customerPrintAll(const CustomerList *list)
{
    int i;

    if (list == NULL) {
        return;
    }
    printf("\n  %-8s %-20s %-16s %10s %8s\n",
           "Account", "Name", "Telephone", "Balance", "Orders");
    printf("  -----------------------------------------------------------------\n");
    if (list->count == 0) {
        printf("  No customer accounts recorded.\n");
        return;
    }
    for (i = 0; i < list->count; i++) {
        customerPrint(&list->items[i]);
    }
    printf("  -----------------------------------------------------------------\n");
    printf("  Total accounts: %d\n", list->count);
}

int customerCount(const CustomerList *list)
{
    if (list == NULL) {
        return 0;
    }
    return list->count;
}

/* ---------------------------------------------------------------------------
 * Persistence
 *
 * File format (one line per customer, fields separated by '|'):
 *   accountId|name|telephone|balance|orderCount
 * Example:
 *   1001|Alice Chen|13800138000|50.00|2
 * ------------------------------------------------------------------------ */

int customerLoad(CustomerList *list, const char *filename)
{
    FILE *fp;
    char line[256];
    char *field[5];
    char *p;
    int  n;
    int  id;
    int  orders;
    double balance;
    Customer c;
    int maxId = CUST_START_ID - 1;
    int status;

    if (list == NULL || filename == NULL) {
        return CUST_ERR_INVALID;
    }

    fp = fopen(filename, "r");
    if (fp == NULL) {
        return CUST_OK;             /* first run: no data file yet */
    }

    while (fgets(line, (int)sizeof(line), fp) != NULL) {
        /* split the line into the five '|'-separated fields */
        field[0] = line;
        n = 1;
        for (p = line; *p != '\0' && n < 5; p++) {
            if (*p == '|') {
                *p = '\0';
                field[n++] = p + 1;
            }
        }
        if (n != 5) {
            continue;               /* skip a damaged line */
        }
        /* strip the trailing newline from the final field */
        p = field[4];
        while (*p != '\0') {
            if (*p == '\n' || *p == '\r') {
                *p = '\0';
                break;
            }
            p++;
        }

        if (sscanf(field[0], "%d", &id) != 1 ||
            sscanf(field[3], "%lf", &balance) != 1 ||
            sscanf(field[4], "%d", &orders) != 1) {
            continue;               /* non-numeric field: skip the record */
        }
        if (!isValidName(field[1]) || !isValidPhone(field[2]) ||
            balance < 0.0 || orders < 0) {
            continue;
        }

        status = ensureCapacity(list);
        if (status != CUST_OK) {
            fclose(fp);
            return status;
        }

        c.accountId = id;
        copyField(c.name, CUST_NAME_LEN, field[1]);
        copyField(c.telephone, CUST_PHONE_LEN, field[2]);
        c.balance = balance;
        c.orderCount = orders;
        list->items[list->count++] = c;

        if (id > maxId) {
            maxId = id;
        }
    }

    fclose(fp);
    list->nextId = maxId + 1;       /* keep account numbers unique on reload */
    return CUST_OK;
}

int customerSave(const CustomerList *list, const char *filename)
{
    FILE *fp;
    int i;

    if (list == NULL || filename == NULL) {
        return CUST_ERR_INVALID;
    }
    fp = fopen(filename, "w");
    if (fp == NULL) {
        return CUST_ERR_IO;
    }
    for (i = 0; i < list->count; i++) {
        fprintf(fp, "%d|%s|%s|%.2f|%d\n",
                list->items[i].accountId,
                list->items[i].name,
                list->items[i].telephone,
                list->items[i].balance,
                list->items[i].orderCount);
    }
    if (fclose(fp) != 0) {
        return CUST_ERR_IO;
    }
    return CUST_OK;
}

/* ---------------------------------------------------------------------------
 * Interactive front-end
 * ------------------------------------------------------------------------ */

/* Internal helper: read a whole line from stdin, removing the newline.
 * Using fgets (instead of scanf) prevents leftover characters from
 * corrupting the next read after an invalid input.                       */
static void readLine(char *buf, int size)
{
    int ch;
    int i;

    if (fgets(buf, size, stdin) == NULL) {
        buf[0] = '\0';
        return;
    }
    i = (int)strlen(buf);
    if (i > 0 && buf[i - 1] == '\n') {
        buf[i - 1] = '\0';
    } else if (i > 0 && buf[i - 1] == '\r') {
        buf[i - 1] = '\0';
    } else {
        /* the line was longer than the buffer: discard the rest */
        while ((ch = getchar()) != '\n' && ch != EOF) {
            /* empty body */
        }
    }
}

/* Internal helper: read an integer, returning 1 on success. */
static int readInt(int *out)
{
    char buf[64];
    char *end;
    long v;

    readLine(buf, (int)sizeof(buf));
    v = strtol(buf, &end, 10);
    while (*end == ' ' || *end == '\t') {
        end++;
    }
    if (end == buf || *end != '\0' || v < INT_MIN || v > INT_MAX) {
        return 0;
    }
    *out = (int)v;
    return 1;
}

/* Internal helper: read a double, returning 1 on success. */
static int readDouble(double *out)
{
    char buf[64];
    char *end;
    double v;

    readLine(buf, (int)sizeof(buf));
    v = strtod(buf, &end);
    while (*end == ' ' || *end == '\t') {
        end++;
    }
    if (end == buf || *end != '\0') {
        return 0;
    }
    *out = v;
    return 1;
}

void customerAccountMenu(CustomerList *list, int isManager)
{
    char name[CUST_NAME_LEN];
    char phone[CUST_PHONE_LEN];
    int  choice;
    int  id;
    int  ok;
    double amount;
    int  status;

    if (list == NULL) {
        return;
    }

    for (;;) {
        printf("\n========== Customer Account System ==========\n");
        printf(" 1. Register a new account\n");
        printf(" 2. View account / check balance\n");
        printf(" 3. Top up (deposit money)\n");
        if (isManager) {
            printf(" 4. Edit account information  [manager]\n");
            printf(" 5. Delete an account          [manager]\n");
            printf(" 6. List all accounts          [manager]\n");
        }
        printf(" 0. Return to main menu\n");
        printf("Select an option: ");

        if (!readInt(&choice)) {
            printf("Invalid input. Please enter a number.\n");
            continue;
        }

        if (choice == 0) {
            break;
        }

        switch (choice) {
        case 1:
            printf("Name     : ");
            readLine(name, (int)sizeof(name));
            printf("Telephone: ");
            readLine(phone, (int)sizeof(phone));
            printf("Initial deposit (0 if none): ");
            if (!readDouble(&amount)) {
                printf("Invalid amount.\n");
                break;
            }
            status = customerRegister(list, name, phone, amount);
            if (status > 0) {
                printf("Account created. Your unique account number is %d.\n", status);
            } else if (status == CUST_ERR_INVALID) {
                printf("Registration failed: invalid name, telephone or amount.\n");
            } else if (status == CUST_ERR_NOMEM) {
                printf("Registration failed: the account database is full.\n");
            } else {
                printf("Registration failed (code %d).\n", status);
            }
            break;

        case 2:
            printf("Enter account number: ");
            if (!readInt(&id)) {
                printf("Invalid account number.\n");
                break;
            }
            ok = (customerFindByIdConst(list, id) != NULL);
            if (ok) {
                customerPrint(customerFindById(list, id));
                printf("Available balance: %.2f\n",
                       customerGetBalance(list, id));
            } else {
                printf("Account %d does not exist.\n", id);
            }
            break;

        case 3:
            printf("Enter account number: ");
            if (!readInt(&id)) {
                printf("Invalid account number.\n");
                break;
            }
            printf("Amount to deposit: ");
            if (!readDouble(&amount)) {
                printf("Invalid amount.\n");
                break;
            }
            status = customerDeposit(list, id, amount);
            if (status == CUST_OK) {
                printf("Deposit successful. New balance: %.2f\n",
                       customerGetBalance(list, id));
            } else if (status == CUST_ERR_NOTFOUND) {
                printf("Account %d does not exist.\n", id);
            } else {
                printf("Deposit failed: amount must be positive and within "
                       "the allowed limit.\n");
            }
            break;

        case 4:
            if (!isManager) {
                printf("This option is available to the manager only.\n");
                break;
            }
            printf("Enter account number to edit: ");
            if (!readInt(&id)) {
                printf("Invalid account number.\n");
                break;
            }
            if (customerFindByIdConst(list, id) == NULL) {
                printf("Account %d does not exist.\n", id);
                break;
            }
            printf("New name (press Enter to keep the current one): ");
            readLine(name, (int)sizeof(name));
            printf("New telephone (press Enter to keep the current one): ");
            readLine(phone, (int)sizeof(phone));
            status = customerEdit(list, id,
                                  (name[0]  != '\0') ? name  : NULL,
                                  (phone[0] != '\0') ? phone : NULL);
            printf("%s\n", (status == CUST_OK) ? "Account updated."
                                               : "Update failed: invalid input.");
            break;

        case 5:
            if (!isManager) {
                printf("This option is available to the manager only.\n");
                break;
            }
            printf("Enter account number to delete: ");
            if (!readInt(&id)) {
                printf("Invalid account number.\n");
                break;
            }
            status = customerDelete(list, id);
            printf("%s\n", (status == CUST_OK) ? "Account deleted."
                                               : "Account not found.");
            break;

        case 6:
            if (!isManager) {
                printf("This option is available to the manager only.\n");
                break;
            }
            customerPrintAll(list);
            break;

        default:
            printf("Unknown option. Please choose again.\n");
            break;
        }
    }
}
