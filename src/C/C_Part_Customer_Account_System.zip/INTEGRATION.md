# Module C — Integration Guide (for the group leader / Module A)

This file explains how to connect `customer.c` / `customer.h` into the whole
Pizza Ordering System. Module C is already self-contained and compiles cleanly
with `-Wall -Wextra -std=c89 -pedantic`.

## 1. Files to include in the submission

- `customer.h` — public interface (keep this name)
- `customer.c` — implementation
- (`test_customer.c` — optional, shows independent module testing)

Add these to the same folder as the group's other `.c` / `.h` files.

## 2. In main.c (Module A)

```c
#include "customer.h"

int main(void)
{
    CustomerList customers;                 /* 1. declare the list        */
    customerListInit(&customers);           /* 2. initialise it           */

    customerLoad(&customers, CUST_DATA_FILE); /* 3. load saved accounts  */

    /* ... login / role selection ... */
    /* After a customer or manager logs in, call:                        */
    /*   customerAccountMenu(&customers, isManager);                     */
    /* where isManager = 1 for the shop manager, 0 for a normal customer */

    customerSave(&customers, CUST_DATA_FILE); /* 4. save before exit     */
    customerListFree(&customers);            /* 5. release memory       */
    return 0;
}
```

## 3. In order.c (Module D) — placing an order

When an order is placed, Module D must check the balance and deduct the money,
then update the order count. **Do not modify `customer.balance` directly** — use
the provided functions so that all checks stay in one place:

```c
#include "customer.h"

/* 'id' is the logged-in customer's account number, 'total' is the order price */
int status = customerCharge(customers, id, total);
if (status == CUST_OK) {
    customerAddOrder(customers, id);   /* record the order in the history */
    /* ... let order.c store the order record with this id ... */
} else if (status == CUST_ERR_INSUFFICIENT) {
    printf("Insufficient balance. Please top up first.\n");
} else if (status == CUST_ERR_NOTFOUND) {
    printf("Account not found.\n");
}
```

`#include "customer.h"` gives Module D access to `Customer`, `CustomerList`,
`CUST_OK`, `CUST_ERR_INSUFFICIENT`, etc. Pass the *same* `CustomerList` object
created in `main.c` (by pointer) to every module — do not create a second one.

## 4. In storage.c (Module A) — optional

`customerSave()` and `customerLoad()` already handle the account data file, so
storage.c does not need to know the `Customer` layout. If storage.c owns all
file handling, simply call these two functions from it instead of from main.c.

File format: `accountId|name|telephone|balance|orderCount` (one line per account).

## 5. Return-value quick reference

| Function | Success | Failure |
|---|---|---|
| `customerRegister` | new account number (> 0) | negative `CustStatus` |
| `customerEdit` / `customerDelete` / `customerDeposit` / `customerCharge` / `customerAddOrder` | `CUST_OK` (0) | negative `CustStatus` |
| `customerGetBalance` | balance (≥ 0) | −1.0 if account missing |
| `customerFindById` / `customerFindByIdConst` | `Customer *` | `NULL` if missing |
| `customerLoad` / `customerSave` | `CUST_OK` (0) | negative `CustStatus` |

`CustStatus` values: `CUST_OK=0`, `CUST_ERR_NOTFOUND=-1`, `CUST_ERR_INVALID=-2`,
`CUST_ERR_INSUFFICIENT=-3`, `CUST_ERR_NOMEM=-4`, `CUST_ERR_IO=-5`,
`CUST_ERR_DUPLICATE=-6`.

## 6. Notes

- Account numbers start at 1001 and are never reused (even after delete/reload).
- A customer can never have a negative balance.
- The order history itself lives in order.c; Module C only keeps `orderCount`.
- To run the independent tests on a machine that allows new executables:

  ```
  gcc -Wall -Wextra -std=c89 -pedantic -o test_customer customer.c test_customer.c
  ./test_customer
  ```
